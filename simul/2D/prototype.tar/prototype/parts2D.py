from constants import *
from velfields import test_turb

def main():
    
    test_turb()


if __name__=='__main__':
    main()
